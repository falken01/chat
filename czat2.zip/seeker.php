<?php
  session_start();
  require_once('connect.php');
  $conn = mysqli_connect($host, $db_user, $db_pass, $db_name);
  $idRozmowy = $_SESSION['idRozmowy'];
  $idOsoby = $_SESSION['id'];
  $resUser = mysqli_query($conn, "SELECT * FROM `metadane_rozmowy` WHERE idRozmowy = '$idRozmowy'");
  $row = $resUser -> fetch_assoc();
  $idDrugiejOsoby = $row['idDrugiejOsoby'];
  if($idDrugiejOsoby != 0 )
  {
    echo "<h5>Połączono z rozmówcą. Przywitaj się!</h5> <br />";
    $result = mysqli_query($conn,"SELECT `wiadomosc`,`nickname` FROM `wiadomosci`, `wszyscy_userzy` WHERE wiadomosci.idRozmowy ='$idRozmowy' AND wszyscy_userzy.id = '$idOsoby'");
    while(list($mess,$nick)=mysqli_fetch_row($result))
    {
      echo "<b>".$nick.": </b>".$mess."<br />";
    }
  } else {
    //zwróć nic
    echo "Oczekiwanie na połączenie z serwerem (xD) ".$idRozmowy;

  }

 ?>
