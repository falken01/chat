<?php
  session_start();
  require_once('connect.php');
  $conn = mysqli_connect($host, $db_user, $db_pass, $db_name);
  $messageFromUser = $_POST['message'];
  $idRozmowy = $_SESSION['idRozmowy'];
  $idOsoby = $_SESSION['id'];
  $result = mysqli_query($conn, "INSERT INTO `wiadomosci` (`idWiadomosci`, `idRozmowy`, `idOsoby`, `wiadomosc`) VALUES (NULL, '$idRozmowy', '$idOsoby', '$messageFromUser');");
  if($result){
   return true;
  }


 ?>
