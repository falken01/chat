<?php
$host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name="czattest";

 ?>
