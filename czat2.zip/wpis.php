<?php

  session_start();
//  if(isset($_POST['nick']))
//  {
    $nick = $_POST['nick'];
    require_once('connect.php');
    $conn = mysqli_connect($host, $db_user, $db_pass, $db_name);
    $res1 = mysqli_query($conn, "SELECT `nickname` FROM `wszyscy_userzy` WHERE `nickname` = '$nick'");
      if(mysqli_num_rows($res1) > 0)
      {
        $_SESSION['blad'] = "Taki nick już istnieje w bazie (ale tylko tymczasowo)";
        header("Location: ./index.php");
      } else {
      $res = mysqli_query($conn, "INSERT INTO `wszyscy_userzy` VALUES (NULL, '$nick')");
      if($res) {
      $resUser = mysqli_query($conn, "SELECT * FROM `wszyscy_userzy` WHERE nickname = '$nick' ");
      $wiersz = $resUser -> fetch_assoc();
      $id = $wiersz['id'];
      $nickname1 = $wiersz['nickname'];
        if($id % 2 == 1)
        {
          $res = mysqli_query($conn, "INSERT INTO `metadane_rozmowy` VALUES(NULL, '$id',0, 0)");
          if($res)
          {
            $resUser = mysqli_query($conn, "SELECT * FROM `metadane_rozmowy` WHERE idPierwszejOsoby = '$id' ");
            $row = $resUser -> fetch_assoc();
            $_SESSION['idRozmowy'] = $row['idRozmowy'];
            $_SESSION['id'] = $id;
            header("Location: ./czat.php");
          }
        } else if ($id % 2 == 0) {
            $resultOfLastRowInRozmowyTbl = mysqli_query($conn,"SELECT `idRozmowy` FROM `metadane_rozmowy` ORDER BY `idRozmowy` DESC LIMIT 1");
            $LastIdOfRozmowa = $resultOfLastRowInRozmowyTbl -> fetch_assoc();
            $LastestID = $LastIdOfRozmowa['idRozmowy'];
            $res =  mysqli_query($conn, "UPDATE `metadane_rozmowy` SET `idDrugiejOsoby` = $id  WHERE `idRozmowy` = $LastestID");
            if($res){
              $resUser = mysqli_query($conn, "SELECT * FROM `metadane_rozmowy` WHERE idDrugiejOsoby = '$id' ");
              $row = $resUser -> fetch_assoc();
              $_SESSION['idRozmowy'] = $row['idRozmowy'];
              $_SESSION['id'] = $id;
              header("Location: ./czat.php");
            }

        }

      }
    }
//  }

?>
